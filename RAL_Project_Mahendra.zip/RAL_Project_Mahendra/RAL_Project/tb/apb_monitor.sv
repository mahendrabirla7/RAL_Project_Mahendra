//
// apb_monitor.sv
// APB Monitor with Functional Coverage
//

import uvm_pkg::*;
`include "uvm_macros.svh"

class apb_monitor extends uvm_monitor;

  `uvm_component_utils(apb_monitor)

  virtual apb_if vif;

  uvm_analysis_port #(apb_rw_seq_item) item_collected_port;

  // --------------------------------------------------
  // Functional Coverage
  // --------------------------------------------------

  covergroup apb_cg with function sample(
    input logic [15:0] addr,
    input bit         is_write,
    input logic [31:0] data,
    input bit         slverr
  );

    // 1. Cover all register addresses
    cp_addr: coverpoint addr {

      bins device_id     = {16'h0000};
      bins version       = {16'h0004};
      bins switch_status = {16'h0008};
      bins port_status   = {16'h000C};

      bins gen_status    = {16'h0010};
      bins stat_rx       = {16'h0014};
      bins stat_tx       = {16'h0018};
      bins stat_drop     = {16'h001C};

      bins switch_ctrl   = {16'h0020};
      bins port_enable   = {16'h0024};
      bins fwd_enable    = {16'h0028};

      bins gen_ctrl      = {16'h002C};
      bins gen_pkt_cfg   = {16'h0030};
      bins gen_interval  = {16'h0034};
      bins gen_count     = {16'h0038};

      bins irq_status    = {16'h003C};
      bins irq_enable    = {16'h0040};
      bins irq_force     = {16'h0044};

      bins err_status    = {16'h0048};
      bins err_enable    = {16'h004C};
      bins err_inject    = {16'h0050};
      bins err_count     = {16'h0054};
      bins err_info      = {16'h0058};

      bins lock_reg      = {16'h005C};
      bins soft_reset    = {16'h0060};
    }

    // 2. Cover READ and WRITE
    cp_operation: coverpoint is_write {
      bins read_op  = {0};
      bins write_op = {1};
    }

    // 3. Cover register address versus operation
    reg_operation_cross: cross cp_addr, cp_operation;

    // 4. Cover APB error response
    cp_slverr: coverpoint slverr {
      bins no_error = {0};
      bins error    = {1};
    }

    // 5. Cover general data patterns
    cp_data: coverpoint data {

      bins zero_data = {32'h00000000};

      bins small_data = {
        [32'h00000001:32'h0000000F]
      };

      bins all_ones = {32'hFFFFFFFF};

      bins other_data = {
        [32'h00000010:32'hFFFFFFFE]
      };
    }

    // 6. Port enable register coverage
    cp_port_enable: coverpoint data[3:0]
      iff (addr == 16'h0024 && is_write) {

      bins disabled     = {4'h0};
      bins port0_only   = {4'h1};
      bins port1_only   = {4'h2};
      bins port2_only   = {4'h4};
      bins port3_only   = {4'h8};
      bins all_enabled  = {4'hF};

      bins partial_enable = {
        4'h3, 4'h5, 4'h6, 4'h7,
        4'h9, 4'hA, 4'hB,
        4'hC, 4'hD, 4'hE
      };
    }

    // 7. Forwarding enable register coverage
    cp_fwd_enable: coverpoint data[3:0]
      iff (addr == 16'h0028 && is_write) {

      bins forwarding_disabled = {4'h0};
      bins forwarding_all      = {4'hF};

      bins forwarding_partial = {
        [4'h1:4'hE]
      };
    }

    // 8. Switch control register coverage
    cp_switch_ctrl: coverpoint data[3:0]
      iff (addr == 16'h0020 && is_write) {

      bins switch_disabled = {4'h0};
      bins switch_enabled  = {4'h1};
      bins irq_enabled     = {4'h8};
      bins switch_irq_on   = {4'h9};

      bins other_control_values = {
        4'h2, 4'h3, 4'h4, 4'h5,
        4'h6, 4'h7, 4'hA, 4'hB,
        4'hC, 4'hD, 4'hE, 4'hF
      };
    }

    // 9. Generator control register coverage
    cp_gen_ctrl: coverpoint data[3:0]
      iff (addr == 16'h002C && is_write) {

      bins gen_disabled  = {4'h0};
      bins gen_enabled   = {4'h1};
      bins continuous    = {4'h8};
      bins enabled_cont  = {4'h9};
    }

    // 10. Packet length coverage
    cp_packet_length: coverpoint data[15:8]
      iff (addr == 16'h0030 && is_write) {

      bins length_1    = {8'd1};
      bins length_2_4  = {[8'd2:8'd4]};
      bins length_5_8  = {[8'd5:8'd8]};
      bins length_9_16 = {[8'd9:8'd16]};
      bins length_gt16 = {[8'd17:8'd255]};
    }

    // 11. Generator source port coverage
    cp_source_port: coverpoint data[3:2]
      iff (addr == 16'h0030 && is_write) {

      bins source_port0 = {2'd0};
      bins source_port1 = {2'd1};
      bins source_port2 = {2'd2};
      bins source_port3 = {2'd3};
    }

    // 12. Generator destination port coverage
    cp_dest_port: coverpoint data[1:0]
      iff (addr == 16'h0030 && is_write) {

      bins dest_port0 = {2'd0};
      bins dest_port1 = {2'd1};
      bins dest_port2 = {2'd2};
      bins dest_port3 = {2'd3};
    }

    // 13. Source and destination combinations
    src_dest_cross: cross cp_source_port, cp_dest_port;

  endgroup : apb_cg

  // --------------------------------------------------
  // Constructor
  // --------------------------------------------------

  function new(string name = "apb_monitor",
               uvm_component parent = null);

    super.new(name, parent);

    item_collected_port = new("item_collected_port", this);

    apb_cg = new();

  endfunction

  // --------------------------------------------------
  // Build Phase
  // --------------------------------------------------

  function void build_phase(uvm_phase phase);

    super.build_phase(phase);

    if (!uvm_config_db#(virtual apb_if)::get(
          this, "", "vif", vif)) begin

      `uvm_fatal("MON", "Virtual interface vif not found")

    end

  endfunction

  // --------------------------------------------------
  // Run Phase
  // --------------------------------------------------

  task run_phase(uvm_phase phase);

    forever begin

      apb_rw_seq_item item;

      // Wait for APB setup phase
      @(vif.monitor_cb);

      if (vif.monitor_cb.psel &&
          !vif.monitor_cb.penable) begin

        item = apb_rw_seq_item::type_id::create("item");

        item.addr = vif.monitor_cb.paddr;

        if (vif.monitor_cb.pwrite)
          item.kind = apb_rw_seq_item::WRITE;
        else
          item.kind = apb_rw_seq_item::READ;

        if (item.kind == apb_rw_seq_item::WRITE)
          item.data = vif.monitor_cb.pwdata;

        // Wait for access completion
        while (!(vif.monitor_cb.penable &&
                 vif.monitor_cb.pready)) begin

          @(vif.monitor_cb);

        end

        if (item.kind == apb_rw_seq_item::READ)
          item.data = vif.monitor_cb.prdata;

        item.slverr = vif.monitor_cb.pslverr;

        // ------------------------------------------
        // Sample functional coverage
        // ------------------------------------------

        apb_cg.sample(
          item.addr,
          (item.kind == apb_rw_seq_item::WRITE),
          item.data,
          item.slverr
        );

        `uvm_info(
          "MON",
          $sformatf(
            "APB %s addr=0x%04h data=0x%08h PSLVERR=%0b Coverage=%.2f%%",
            item.kind.name(),
            item.addr,
            item.data,
            item.slverr,
            apb_cg.get_coverage()
          ),
          UVM_MEDIUM
        )

        // Send transaction to predictor and subscribers
        item_collected_port.write(item);

        @(vif.monitor_cb);

      end

    end

  endtask

  // --------------------------------------------------
  // Report Phase
  // --------------------------------------------------

  function void report_phase(uvm_phase phase);

    super.report_phase(phase);

    `uvm_info(
      "COVERAGE",
      $sformatf(
        "APB Functional Coverage = %.2f%%",
        apb_cg.get_coverage()
      ),
      UVM_NONE
    )

    `uvm_info(
      "COVERAGE",
      $sformatf(
        "Register Address Coverage = %.2f%%",
        apb_cg.cp_addr.get_coverage()
      ),
      UVM_NONE
    )

    `uvm_info(
      "COVERAGE",
      $sformatf(
        "Register/Operation Cross Coverage = %.2f%%",
        apb_cg.reg_operation_cross.get_coverage()
      ),
      UVM_NONE
    )

  endfunction

endclass : apb_monitor
