//
// tb_top.sv
// Top-Level UVM Testbench Module
//
`timescale 1ns / 1ps

module tb_top;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import apb_pkt_pkg::*;
  import pkt_ral_pkg::*;
  import pkt_env_pkg::*;
  import pkt_test_pkg::*;

  logic pclk;
  logic presetn;

  // Clock generation (100MHz)
  initial begin
    pclk = 0;
    forever #5 pclk = ~pclk;
  end

  // Reset generation
  initial begin
    presetn = 0;
    #20;
    presetn = 1;
  end

  // Interface instantiation
  apb_if vif(pclk, presetn);

  // DUT instantiation
  apb_pkt_switch dut (
    .pclk    (vif.pclk),
    .presetn (vif.presetn),
    .psel    (vif.psel),
    .penable (vif.penable),
    .pwrite  (vif.pwrite),
    .paddr   (vif.paddr),
    .pwdata  (vif.pwdata),
    .prdata  (vif.prdata),
    .pready  (vif.pready),
    .pslverr (vif.pslverr),
    .irq     (vif.irq)
  );

  initial begin
    uvm_config_db#(virtual apb_if)::set(null, "uvm_test_top.env.agent*", "vif", vif);
    run_test();
  end

//initial begin
//#1000;
//$finish();
//end

endmodule
