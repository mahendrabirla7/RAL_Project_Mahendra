//
// pkt_env_pkg.sv
// UVM Environment Package
//
package pkt_env_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import apb_pkt_pkg::*;
  import pkt_ral_pkg::*;

  `include "apb_rw_seq_item.sv"
  `include "apb_driver.sv"
  `include "apb_monitor.sv"
  `include "apb_reg_adapter.sv"

  class apb_agent extends uvm_agent;
    `uvm_component_utils(apb_agent)

    apb_driver                      driver;
    apb_monitor                     monitor;
    uvm_sequencer #(apb_rw_seq_item) sequencer;

    function new(string name = "apb_agent", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      monitor = apb_monitor::type_id::create("monitor", this);
      if (get_is_active() == UVM_ACTIVE) begin
        driver    = apb_driver::type_id::create("driver", this);
        sequencer = uvm_sequencer#(apb_rw_seq_item)::type_id::create("sequencer", this);
      end
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      if (get_is_active() == UVM_ACTIVE) begin
        driver.seq_item_port.connect(sequencer.seq_item_export);
      end
    endfunction
  endclass : apb_agent

  class pkt_env extends uvm_env;
    `uvm_component_utils(pkt_env)

    apb_agent                            agent;
    pkt_reg_block                        reg_model;
    apb_reg_adapter                      adapter;
    uvm_reg_predictor #(apb_rw_seq_item) predictor;

    function new(string name = "pkt_env", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      agent     = apb_agent::type_id::create("agent", this);
      reg_model = pkt_reg_block::type_id::create("reg_model", this);
      reg_model.build();
      reg_model.lock_model();

      adapter   = apb_reg_adapter::type_id::create("adapter", this);
      predictor = uvm_reg_predictor#(apb_rw_seq_item)::type_id::create("predictor", this);
    endfunction

    function void connect_phase(uvm_phase phase);
      super.connect_phase(phase);
      reg_model.apb_map.set_sequencer(agent.sequencer, adapter);
      reg_model.apb_map.set_auto_predict(0);

      predictor.map     = reg_model.apb_map;
      predictor.adapter = adapter;
      agent.monitor.item_collected_port.connect(predictor.bus_in);
    endfunction
  endclass : pkt_env

endpackage : pkt_env_pkg
