//
// apb_driver.sv
// APB Driver Component
//
import uvm_pkg::*;
`include "uvm_macros.svh"

class apb_driver extends uvm_driver #(apb_rw_seq_item);
  `uvm_component_utils(apb_driver)

  virtual apb_if vif;

  function new(string name = "apb_driver", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("DRV", "Virtual interface vif not found in config_db")
  endfunction

  task run_phase(uvm_phase phase);
    vif.master_cb.psel    <= 1'b0;
    vif.master_cb.penable <= 1'b0;
    vif.master_cb.pwrite  <= 1'b0;
    vif.master_cb.paddr   <= '0;
    vif.master_cb.pwdata  <= '0;
  
// Do not start APB transactions during reset.
  wait (vif.presetn === 1'b1);
  @(vif.master_cb);

    forever begin
      seq_item_port.get_next_item(req);
      drive_pkt(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_pkt(apb_rw_seq_item item);
    `uvm_info("DRV", "Inside DRIVER", UVM_LOW)

    // 1. SETUP PHASE
    @(vif.master_cb);
    vif.master_cb.psel    <= 1'b1;
    vif.master_cb.penable <= 1'b0;
    vif.master_cb.paddr   <= item.addr;
    vif.master_cb.pwrite  <= (item.kind == apb_rw_seq_item::WRITE);
    if (item.kind == apb_rw_seq_item::WRITE) begin
      vif.master_cb.pwdata <= item.data;
    end
    `uvm_info("DRV", "Setup phase ends", UVM_LOW)

    // 2. ACCESS PHASE
    @(vif.master_cb);
    vif.master_cb.penable <= 1'b1;
    `uvm_info("DRV", "Access phase ends DRIVER", UVM_LOW)
    $display("pkt: %p", item);

    // Wait for PREADY assertion
    while (!vif.master_cb.pready) begin
      @(vif.master_cb);
    end
    `uvm_info("DRV", "Handshake done", UVM_LOW)

    if (item.kind == apb_rw_seq_item::READ) begin
      item.data = vif.master_cb.prdata;
    end
    item.slverr = vif.master_cb.pslverr;

    // 3. END PHASE / IDLE RETURN
    @(vif.master_cb);
    vif.master_cb.psel    <= 1'b0;
    vif.master_cb.penable <= 1'b0;
    vif.master_cb.pwrite  <= 1'b0;
  endtask
endclass : apb_driver
