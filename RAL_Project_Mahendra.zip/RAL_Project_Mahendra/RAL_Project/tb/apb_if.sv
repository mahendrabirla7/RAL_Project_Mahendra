//
// apb_if.sv
// AMBA APB3 Interface Definition
//
interface apb_if #(
  parameter int ADDR_W = 16,
  parameter int DATA_W = 32
)(
  input logic pclk,
  input logic presetn
);

  logic               psel;
  logic               penable;
  logic               pwrite;
  logic [ADDR_W-1:0]  paddr;
  logic [DATA_W-1:0]  pwdata;
  logic [DATA_W-1:0]  prdata;
  logic               pready;
  logic               pslverr;
  logic               irq;

  clocking master_cb @(posedge pclk);
    default input #1step output #1;
    output psel, penable, pwrite, paddr, pwdata;
    input  prdata, pready, pslverr, irq;
  endclocking

  clocking monitor_cb @(posedge pclk);
    default input #1step output #1;
    input psel, penable, pwrite, paddr, pwdata, prdata, pready, pslverr, irq;
  endclocking

  modport master  (clocking master_cb, input pclk, presetn);
  modport monitor (clocking monitor_cb, input pclk, presetn);

endinterface : apb_if
