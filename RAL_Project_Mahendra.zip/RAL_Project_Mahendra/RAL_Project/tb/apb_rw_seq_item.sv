//
// apb_rw_seq_item.sv
// APB Sequence Item Class
//
import uvm_pkg::*;
`include "uvm_macros.svh"

class apb_rw_seq_item extends uvm_sequence_item;
  typedef enum {READ, WRITE} kind_e;

  rand kind_e           kind;
  rand bit [16-1:0]     addr;
  rand bit [32-1:0]     data;
  bit                   slverr;

  `uvm_object_utils_begin(apb_rw_seq_item)
    `uvm_field_enum(kind_e, kind, UVM_ALL_ON)
    `uvm_field_int(addr, UVM_ALL_ON)
    `uvm_field_int(data, UVM_ALL_ON)
    `uvm_field_int(slverr, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "apb_rw_seq_item");
    super.new(name);
  endfunction
endclass : apb_rw_seq_item
