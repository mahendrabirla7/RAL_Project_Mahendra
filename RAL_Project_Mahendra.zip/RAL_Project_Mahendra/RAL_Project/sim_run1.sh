

#!/bin/bash

###############################################################################
# APB PACKET SWITCH - UVM RAL SIMULATION SCRIPT
#
# Supported simulators:
#   1. QuestaSim
#   2. Synopsys VCS
#   3. Cadence Xcelium
#
# Usage:
#   ./run_sim.sh questa
#   ./run_sim.sh vcs
#   ./run_sim.sh xcelium
#
###############################################################################

set -Eeuo pipefail

SIM_TOOL="${1:-questa}"

###############################################################################
# CONFIGURATION
###############################################################################

TESTS=(
    "base_test"
    "error_injection_test"
    "exhaustive_config_test"
    "random_packet_test"
)

RTL_FILES=(
    rtl/apb_pkt_pkg.sv
    rtl/pkt_generator.sv
    rtl/pkt_switch.sv
    rtl/apb_pkt_switch.sv
)

TB_FILES=(
    ral/pkt_ral_pkg.sv
    tb/apb_if.sv
    tb/pkt_env_pkg.sv
    tests/pkt_test_pkg.sv
    tb/tb_top.sv
)

ALL_FILES=("${RTL_FILES[@]}" "${TB_FILES[@]}")

COVERAGE_DIR="coverage"

# Update this path if your Questa installation is different.
QUESTA_UVM_DPI="C:/questasim64_10.7c/uvm-1.1d/win64/uvm_dpi"

###############################################################################
# COMMON FUNCTIONS
###############################################################################

print_header()
{
    echo
    echo "=========================================================="
    echo " $1"
    echo "=========================================================="
}

check_tool()
{
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "ERROR: Required tool '$1' not found in PATH."
        exit 1
    fi
}

check_sources()
{
    for file in "${ALL_FILES[@]}"; do
        if [ ! -f "$file" ]; then
            echo "ERROR: Source file not found: $file"
            exit 1
        fi
    done
}

prepare_directories()
{
    mkdir -p "$COVERAGE_DIR"
}

###############################################################################
# QUESTA SIMULATION
###############################################################################

run_questa()
{
    check_tool vlog
    check_tool vlib
    check_tool vopt
    check_tool vsim
    check_tool vcover

    print_header "QUESTASIM COMPILATION"

    # Clean previous simulation library and coverage files.
    rm -rf work
    rm -f "$COVERAGE_DIR"/*.ucdb

    vlib work

    # Compile RTL and testbench with code coverage instrumentation.
    vlog -sv \
         -cover bcesft \
         -timescale 1ns/1ps \
         +incdir+rtl \
         +incdir+ral \
         +incdir+tb \
         +incdir+tests \
         "${ALL_FILES[@]}"

    if [ ! -d work ]; then
        echo "ERROR: Questa work library was not created."
        exit 1
    fi

    print_header "QUESTASIM OPTIMIZATION"

    vopt tb_top -o opt_tb_top +acc

    print_header "QUESTASIM TEST EXECUTION"

    local UCDB_FILES=()

    for test_name in "${TESTS[@]}"; do

        print_header "RUNNING TEST: $test_name"

        local UCDB_FILE="${COVERAGE_DIR}/${test_name}_cov.ucdb"

        rm -f "$UCDB_FILE"

        # Run simulation and save coverage after run -all.
        vsim -c \
             -coverage \
             opt_tb_top \
             -sv_lib "$QUESTA_UVM_DPI" \
             "+UVM_TESTNAME=${test_name}" \
             +UVM_OBJECTION_TRACE \
             -do "run -all; coverage save -codeAll -cvg -assert {${UCDB_FILE}}; quit -f"

        # Check generated coverage database.
        if [ -s "$UCDB_FILE" ]; then
            echo "SUCCESS: Coverage saved: $UCDB_FILE"
            UCDB_FILES+=("$UCDB_FILE")
        else
            echo "ERROR: Coverage database missing or empty for $test_name"
            exit 1
        fi

    done

    print_header "MERGING QUESTA COVERAGE"

    if [ "${#UCDB_FILES[@]}" -eq 0 ]; then
        echo "ERROR: No coverage databases available."
        exit 1
    fi

    vcover merge \
        -out "${COVERAGE_DIR}/merged_coverage.ucdb" \
        "${UCDB_FILES[@]}"

    print_header "QUESTA COVERAGE REPORT"

    vcover report -details "${COVERAGE_DIR}/merged_coverage.ucdb"

    echo
    echo "Merged UCDB:"
    echo "${COVERAGE_DIR}/merged_coverage.ucdb"

    echo
    echo "Open coverage GUI using:"
    echo "vsim -gui -viewcov ${COVERAGE_DIR}/merged_coverage.ucdb"
}

###############################################################################
# VCS SIMULATION
###############################################################################

run_vcs()
{
    check_tool vcs
    check_tool urg

    print_header "VCS COMPILATION"

    mkdir -p vcs_coverage

    vcs -full64 \
        -sverilog \
        -ntb_opts uvm-1.2 \
        -cm line+cond+fsm+tgl+branch \
        +incdir+rtl \
        +incdir+ral \
        +incdir+tb \
        +incdir+tests \
        "${ALL_FILES[@]}" \
        -o simv

    print_header "VCS TEST EXECUTION"

    local VDB_DIRS=()

    for test_name in "${TESTS[@]}"; do

        print_header "RUNNING TEST: $test_name"

        local VDB_DIR="vcs_coverage/${test_name}.vdb"

        rm -rf "$VDB_DIR"

        ./simv \
            "+UVM_TESTNAME=${test_name}" \
            -cm line+cond+fsm+tgl+branch \
            -cm_dir "$VDB_DIR" \
            -cm_name "$test_name"

        if [ -d "$VDB_DIR" ]; then
            echo "SUCCESS: VCS coverage saved: $VDB_DIR"
            VDB_DIRS+=("$VDB_DIR")
        else
            echo "ERROR: VCS coverage missing for $test_name"
            exit 1
        fi

    done

    print_header "MERGING VCS COVERAGE"

    urg -dir "${VDB_DIRS[@]}" \
        -format both \
        -report vcs_coverage/merged_report

    echo "VCS coverage report: vcs_coverage/merged_report"
}

###############################################################################
# XCELIUM SIMULATION
###############################################################################

run_xcelium()
{
    check_tool xrun

    print_header "XCELIUM COMPILATION"

    mkdir -p xcelium_coverage

    # Compile and elaborate once.
    xrun -64bit \
         -uvmhome UVM12 \
         -coverage all \
         -covoverwrite \
         -elaborate \
         -top tb_top \
         +incdir+rtl \
         +incdir+ral \
         +incdir+tb \
         +incdir+tests \
         "${ALL_FILES[@]}"

    print_header "XCELIUM TEST EXECUTION"

    for test_name in "${TESTS[@]}"; do

        print_header "RUNNING TEST: $test_name"

        xrun -64bit \
             -R \
             -coverage all \
             -covoverwrite \
             -covtest "$test_name" \
             -covworkdir "xcelium_coverage/${test_name}.covwork" \
             "+UVM_TESTNAME=${test_name}"

    done

    print_header "XCELIUM COVERAGE MERGE"

    if command -v imc >/dev/null 2>&1; then
        imc -exec "
            merge -runfile xcelium_coverage \
            -out xcelium_coverage/merged_coverage
        "
    else
        echo "WARNING: IMC not found in PATH."
        echo "Merge the Xcelium coverage runs using IMC."
    fi

}

###############################################################################
# MAIN
###############################################################################

print_header "APB PACKET SWITCH UVM RAL TESTBENCH"

echo "Simulator: $SIM_TOOL"
echo "Tests:"
printf '  %s\n' "${TESTS[@]}"

check_sources
prepare_directories

case "$SIM_TOOL" in

    questa)
        run_questa
        ;;

    vcs)
        run_vcs
        ;;

    xcelium)
        run_xcelium
        ;;

    *)
        echo "ERROR: Unknown simulator: $SIM_TOOL"
        echo "Supported options: questa, vcs, xcelium"
        exit 1
        ;;

esac

print_header "ALL SIMULATIONS COMPLETED"
