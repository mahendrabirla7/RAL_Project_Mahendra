//
// pkt_test_pkg.sv
package pkt_test_pkg;
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import apb_pkt_pkg::*;
  import pkt_ral_pkg::*;
  import pkt_env_pkg::*;

  // ---------------------------------------------------------------------------
  // 1. Base / Standard Packet Run Sequence
  // ---------------------------------------------------------------------------
  class ral_packet_run_seq extends uvm_sequence;
    `uvm_object_utils(ral_packet_run_seq)

    pkt_reg_block reg_model;
    uvm_status_e  status;
    uvm_reg_data_t rdata;

    function new(string name = "ral_packet_run_seq");
      super.new(name);
    endfunction

    task body();
      int timeout_counter = 0;

      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      `uvm_info("SEQ", "Step 1: Unlocking register bank...", UVM_LOW)
      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

      `uvm_info("SEQ", "Step 2: Enabling destination ports and forwarding policy...", UVM_LOW)
      reg_model.port_enable.write(status, 32'h0000000F);
      reg_model.fwd_enable.write(status, 32'h0000000F);

      `uvm_info("SEQ", "Step 3: Enabling packet switch fabric and global interrupt...", UVM_LOW)
      reg_model.switch_ctrl.write(status, 32'h00000009);

      `uvm_info("SEQ", "Step 4: Programming packet generator parameters...", UVM_LOW)
      reg_model.gen_pkt_cfg.write(status, 32'h00100401); 
      reg_model.gen_interval.write(status, 32'h00000002);
      reg_model.gen_count.write(status, 32'h00000004);

      `uvm_info("SEQ", "Step 5: Enabling interrupts (GEN_DONE & START_ACK)...", UVM_LOW)
      reg_model.irq_enable.write(status, 32'h00000041);

      `uvm_info("SEQ", "Step 6: Triggering generator run (ENABLE + START)...", UVM_LOW)
      reg_model.gen_ctrl.write(status, 32'h00000003);

      `uvm_info("SEQ", "Step 7: Polling generator status until DONE...", UVM_LOW)
      do begin
        #100ns;
        reg_model.gen_status.read(status, rdata);
        timeout_counter++;
        if (timeout_counter > 2000) begin
          `uvm_fatal("SEQ", "Timeout waiting for generator DONE status!")
          break;
        end
      end while (rdata[1] != 1'b1);

      `uvm_info("SEQ", "Step 8: Reading back statistics counters...", UVM_LOW)
      reg_model.stat_rx.read(status, rdata);
      `uvm_info("SEQ", $sformatf("STAT_RX = %0d", rdata), UVM_LOW)
      reg_model.stat_tx.read(status, rdata);
      `uvm_info("SEQ", $sformatf("STAT_TX = %0d", rdata), UVM_LOW)
    endtask
  endclass : ral_packet_run_seq

  // ---------------------------------------------------------------------------
  // 2. Error Injection Sequence
  // ---------------------------------------------------------------------------
  class ral_error_injection_seq extends uvm_sequence;
    `uvm_object_utils(ral_error_injection_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;
    uvm_reg_data_t rdata;

    function new(string name = "ral_error_injection_seq");
      super.new(name);
    endfunction

    task body();
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      `uvm_info("SEQ", "Injecting error: Writing to protected register without unlocking...", UVM_LOW)
      reg_model.port_enable.write(status, 32'h0000000F);
      
      `uvm_info("SEQ", "Reading status register to check error behavior...", UVM_LOW)
      reg_model.gen_status.read(status, rdata);
    endtask
  endclass : ral_error_injection_seq

  // ---------------------------------------------------------------------------
  // 3. Exhaustive Configuration Sequence
  // ---------------------------------------------------------------------------
  class ral_exhaustive_config_seq extends uvm_sequence;
    `uvm_object_utils(ral_exhaustive_config_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;

    function new(string name = "ral_exhaustive_config_seq");
      super.new(name);
    endfunction

    task body();
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

      for (int i = 1; i < 16; i++) begin
        reg_model.port_enable.write(status, i);
        reg_model.fwd_enable.write(status, i & 4'hC);
        reg_model.switch_ctrl.write(status, i[0] ? 32'h00000009 : 32'h00000005);
        reg_model.gen_pkt_cfg.write(status, (i << 16) | 32'h00000401);
      end
    endtask
  endclass : ral_exhaustive_config_seq

  // ---------------------------------------------------------------------------
  // 4. Randomized Stress Sequence
  // ---------------------------------------------------------------------------
  class ral_random_packet_seq extends uvm_sequence;
    `uvm_object_utils(ral_random_packet_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;
    uvm_reg_data_t rdata;

    function new(string name = "ral_random_packet_seq");
      super.new(name);
    endfunction

    task body();
      int timeout_counter;
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

      repeat (10) begin
        uvm_reg_data_t p_en = $urandom_range(1, 15);
        uvm_reg_data_t f_en = $urandom_range(1, 15);
        
        reg_model.port_enable.write(status, p_en);
        reg_model.fwd_enable.write(status, f_en);
        reg_model.switch_ctrl.write(status, 32'h00000009);
        reg_model.gen_pkt_cfg.write(status, $urandom());
        reg_model.gen_interval.write(status, $urandom_range(1, 5));
        reg_model.gen_count.write(status, $urandom_range(1, 10));
        reg_model.gen_ctrl.write(status, 32'h00000003);

        timeout_counter = 0;
        do begin
          #100ns;
          reg_model.gen_status.read(status, rdata);
          timeout_counter++;
          if (timeout_counter > 1000) break;
        end while (rdata[1] != 1'b1);
      end
    endtask
  endclass : ral_random_packet_seq



  // ---------------------------------------------------------------------------
  // 5. ral_backdoor_write_frontdoor_read_seq 
  // ---------------------------------------------------------------------------
  class ral_backdoor_write_frontdoor_read_seq extends uvm_sequence;
    `uvm_object_utils(ral_backdoor_write_frontdoor_read_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;
    uvm_reg_data_t rdata;

    function new(string name = "ral_backdoor_write_frontdoor_read_seq");
      super.new(name);
    endfunction

    task body();
      int timeout_counter;
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

    `uvm_info(get_type_name(), "ral_backdoor_write_frontdoor_read_seq: Inside Body", UVM_LOW);
    reg_model.port_enable.write(status, 32'h0000_0003,UVM_BACKDOOR);
    reg_model.port_enable.read(status, rdata);
endtask
endclass
    
// ---------------------------------------------------------------------------
  // 6. Frontdoor Write & Backdoor Read Sequence
  // ---------------------------------------------------------------------------
  class ral_frontdoor_write_backdoor_read_seq extends uvm_sequence;
    `uvm_object_utils(ral_frontdoor_write_backdoor_read_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;
    uvm_reg_data_t rdata;

    function new(string name = "ral_frontdoor_write_backdoor_read_seq");
      super.new(name);
    endfunction

    task body();
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      `uvm_info("SEQ", "Unlocking register bank via Frontdoor...", UVM_LOW)
      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

      `uvm_info("SEQ", "Performing Frontdoor WRITE on gen_interval...", UVM_LOW)
      reg_model.gen_interval.write(status, 32'h0000000A);

      `uvm_info("SEQ", "Performing Backdoor READ on gen_interval...", UVM_LOW)
      reg_model.gen_interval.read(status, rdata, UVM_BACKDOOR);

      `uvm_info("SEQ", $sformatf("Backdoor READ data = 0x%0h", rdata), UVM_LOW)
    endtask
  endclass : ral_frontdoor_write_backdoor_read_seq


// ---------------------------------------------------------------------------
  // 7. All Registers Exhaustive Exercise Sequence
  // ---------------------------------------------------------------------------
  class ral_all_registers_seq extends uvm_sequence;
    `uvm_object_utils(ral_all_registers_seq)

    pkt_reg_block reg_model;
    uvm_status_e status;
    uvm_reg regs[$];
    uvm_reg_data_t rdata;

    function new(string name = "ral_all_registers_seq");
      super.new(name);
    endfunction

    task body();
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      // First unlock the register bank if protected
      `uvm_info("SEQ", "Unlocking register bank for full register scan...", UVM_LOW)
      reg_model.lock_reg.write(status, 32'hA5A5C3C3);

      // Get a queue of all registers contained within the block
      reg_model.get_registers(regs);

      `uvm_info("SEQ", $sformatf("Starting exercise across all %0d registers...", regs.size()), UVM_LOW)

      // Loop through every single register in the block
      foreach (regs[i]) begin
        uvm_reg rg = regs[i];
        
        `uvm_info("SEQ", $sformatf("Accessing register: %s", rg.get_name()), UVM_LOW)
        
        // Perform a frontdoor write with a test pattern
        rg.write(status, 32'h12345678);
        
        // Perform a frontdoor read back
        rg.read(status, rdata);
      end

      `uvm_info("SEQ", "Completed exercising all registers successfully!", UVM_LOW)
    endtask
  endclass : ral_all_registers_seq

// ---------------------------------------------------------------------------
  // 8. Built-in UVM Register Test Sequences Wrapper
  // ---------------------------------------------------------------------------
  class ral_builtin_reg_seq extends uvm_sequence;
    `uvm_object_utils(ral_builtin_reg_seq)

    pkt_reg_block reg_model;

    function new(string name = "ral_builtin_reg_seq");
      super.new(name);
    endfunction

    task body();
      if (reg_model == null) begin
        `uvm_fatal("SEQ", "Register model handle is null")
        return;
      end

      // 1. Run Hardware Reset Sequence (checks default/reset values of all registers)
      begin
        uvm_reg_hw_reset_seq rst_seq = uvm_reg_hw_reset_seq::type_id::create("rst_seq");
        `uvm_info("SEQ", "Starting built-in HW Reset sequence...", UVM_LOW)
        rst_seq.model = reg_model;
        rst_seq.start(null);
      end

      // 2. Run Bit Bash Sequence (tests read/write behavior on every single writable bit)
      begin
        uvm_reg_bit_bash_seq bash_seq = uvm_reg_bit_bash_seq::type_id::create("bash_seq");
        `uvm_info("SEQ", "Starting built-in Bit Bash sequence...", UVM_LOW)
        bash_seq.model = reg_model;
        bash_seq.start(null);
      end

      // 3. Run Access Sequence (verifies frontdoor and backdoor read/write integrity)
      begin
        uvm_reg_access_seq acc_seq = uvm_reg_access_seq::type_id::create("acc_seq");
        `uvm_info("SEQ", "Starting built-in Access sequence...", UVM_LOW)
        acc_seq.model = reg_model;
        acc_seq.start(null);
      end
    endtask
  endclass : ral_builtin_reg_seq


  // ---------------------------------------------------------------------------
  // 9. Test Definitions
  // ---------------------------------------------------------------------------

  class base_test extends uvm_test;
    `uvm_component_utils(base_test)

    pkt_env env;

    function new(string name = "base_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
      super.build_phase(phase);
      env = pkt_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
      ral_packet_run_seq seq;
      phase.raise_objection(this);
      seq = ral_packet_run_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : base_test

  class error_injection_test extends base_test;
    `uvm_component_utils(error_injection_test)

    function new(string name = "error_injection_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_error_injection_seq seq;
      phase.raise_objection(this);
      seq = ral_error_injection_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #100ns;
      phase.drop_objection(this);
    endtask
  endclass : error_injection_test

  class exhaustive_config_test extends base_test;
    `uvm_component_utils(exhaustive_config_test)

    function new(string name = "exhaustive_config_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_exhaustive_config_seq seq;
      phase.raise_objection(this);
      seq = ral_exhaustive_config_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : exhaustive_config_test

  class random_packet_test extends base_test;
    `uvm_component_utils(random_packet_test)

    function new(string name = "random_packet_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_random_packet_seq seq;
      phase.raise_objection(this);
      seq = ral_random_packet_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : random_packet_test

class backdoor_write_frontdoor_read_test extends base_test;
    `uvm_component_utils(backdoor_write_frontdoor_read_test)

    function new(string name = "backdoor_write_frontdoor_read_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_backdoor_write_frontdoor_read_seq seq;
      phase.raise_objection(this);
      seq = ral_backdoor_write_frontdoor_read_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : backdoor_write_frontdoor_read_test


  class frontdoor_write_backdoor_read_test extends base_test;
    `uvm_component_utils(frontdoor_write_backdoor_read_test)

    function new(string name = "frontdoor_write_backdoor_read_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_frontdoor_write_backdoor_read_seq seq;
      phase.raise_objection(this);
      seq = ral_frontdoor_write_backdoor_read_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : frontdoor_write_backdoor_read_test

   class all_registers_test extends base_test;
    `uvm_component_utils(all_registers_test)

    function new(string name = "all_registers_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_all_registers_seq seq;
      phase.raise_objection(this);
      seq = ral_all_registers_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : all_registers_test

  // Test Definition for Built-in Sequences
  class builtin_reg_test extends base_test;
    `uvm_component_utils(builtin_reg_test)

    function new(string name = "builtin_reg_test", uvm_component parent = null);
      super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
      ral_builtin_reg_seq seq;
      phase.raise_objection(this);
      seq = ral_builtin_reg_seq::type_id::create("seq");
      seq.reg_model = env.reg_model;
      seq.start(env.agent.sequencer);
      #200ns;
      phase.drop_objection(this);
    endtask
  endclass : builtin_reg_test
endpackage : pkt_test_pkg
