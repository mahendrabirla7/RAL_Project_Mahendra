//
// apb_reg_adapter.sv
// APB Bus Adapter for UVM RAL
//
import uvm_pkg::*;
`include "uvm_macros.svh"

class apb_reg_adapter extends uvm_reg_adapter;
  `uvm_object_utils(apb_reg_adapter)

  function new(string name = "apb_reg_adapter");
    super.new(name);
    //supports_byte_enable = 0;
    //provides_responses   = 0;
  endfunction

  virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
    apb_rw_seq_item item = apb_rw_seq_item::type_id::create("item");
    item.kind = (rw.kind == UVM_WRITE) ? apb_rw_seq_item::WRITE : apb_rw_seq_item::READ;
    item.addr = rw.addr;
    item.data = rw.data;
    
    // Fixed typo ($sformatf) and enum string conversion (.name())
    `uvm_info("ADP", $sformatf("item.kind: %0s, item.addr: %0h, item.data: %0h", item.kind.name(), item.addr, item.data), UVM_LOW)
    
    return item;
  endfunction

  virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
    apb_rw_seq_item item;
    if (!$cast(item, bus_item)) begin
      `uvm_fatal("ADAPTER", "Failed to cast bus_item to apb_rw_seq_item")
      return;
    end
    rw.kind   = (item.kind == apb_rw_seq_item::WRITE) ? UVM_WRITE : UVM_READ;
    rw.addr   = item.addr;
    rw.data   = item.data;
    rw.status = item.slverr ? UVM_NOT_OK : UVM_IS_OK;
  endfunction
endclass : apb_reg_adapter
