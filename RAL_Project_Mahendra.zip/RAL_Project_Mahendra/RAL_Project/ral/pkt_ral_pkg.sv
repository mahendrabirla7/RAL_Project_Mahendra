//
// pkt_ral_pkg.sv
// Complete UVM RAL Package for APB Packet Switch (25 Registers) with Verified HDL Paths
//
package pkt_ral_pkg;

  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // Base Register Definition Class
  class pkt_reg_base extends uvm_reg;
    uvm_reg_data_t default_value;

    function new(string name = "pkt_reg_base", int unsigned n_bits = 32, int has_coverage = UVM_NO_COVERAGE);
      super.new(name, n_bits, has_coverage);
    endfunction

    virtual function void build();
    endfunction
  endclass : pkt_reg_base

  // Register: DEVICE_ID
  class reg_device_id extends pkt_reg_base;
    `uvm_object_utils(reg_device_id)
    uvm_reg_field val;
    function new(string name = "reg_device_id"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 0, 32'h02A55357, 1, 0, 1);
    endfunction
  endclass

  // Register: VERSION
  class reg_version extends pkt_reg_base;
    `uvm_object_utils(reg_version)
    uvm_reg_field val;
    function new(string name = "reg_version"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 0, 32'h00010200, 1, 0, 1);
    endfunction
  endclass

  // Register: SWITCH_STATUS
  class reg_switch_status extends pkt_reg_base;
    `uvm_object_utils(reg_switch_status)
    uvm_reg_field val;
    function new(string name = "reg_switch_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h000000F9, 1, 0, 1);
    endfunction
  endclass

  // Register: PORT_STATUS
  class reg_port_status extends pkt_reg_base;
    `uvm_object_utils(reg_port_status)
    uvm_reg_field val;
    function new(string name = "reg_port_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: GEN_STATUS
  class reg_gen_status extends pkt_reg_base;
    `uvm_object_utils(reg_gen_status)
    uvm_reg_field val;
    function new(string name = "reg_gen_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: STAT_RX
  class reg_stat_rx extends pkt_reg_base;
    `uvm_object_utils(reg_stat_rx)
    uvm_reg_field val;
    function new(string name = "reg_stat_rx"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: STAT_TX
  class reg_stat_tx extends pkt_reg_base;
    `uvm_object_utils(reg_stat_tx)
    uvm_reg_field val;
    function new(string name = "reg_stat_tx"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: STAT_DROP
  class reg_stat_drop extends pkt_reg_base;
    `uvm_object_utils(reg_stat_drop)
    uvm_reg_field val;
    function new(string name = "reg_stat_drop"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: SWITCH_CTRL
  class reg_switch_ctrl extends pkt_reg_base;
    `uvm_object_utils(reg_switch_ctrl)
    uvm_reg_field val;
    function new(string name = "reg_switch_ctrl"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: PORT_ENABLE
  class reg_port_enable extends pkt_reg_base;
    `uvm_object_utils(reg_port_enable)
    uvm_reg_field val;
    function new(string name = "reg_port_enable"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h0000000F, 1, 0, 1);
    endfunction
  endclass

  // Register: FWD_ENABLE
  class reg_fwd_enable extends pkt_reg_base;
    `uvm_object_utils(reg_fwd_enable)
    uvm_reg_field val;
    function new(string name = "reg_fwd_enable"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h0000000F, 1, 0, 1);
    endfunction
  endclass

  // Register: GEN_CTRL
  class reg_gen_ctrl extends pkt_reg_base;
    `uvm_object_utils(reg_gen_ctrl)
    uvm_reg_field val;
    function new(string name = "reg_gen_ctrl"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: GEN_PKT_CFG
  class reg_gen_pkt_cfg extends pkt_reg_base;
    `uvm_object_utils(reg_gen_pkt_cfg)
    uvm_reg_field val;
    function new(string name = "reg_gen_pkt_cfg"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000401, 1, 0, 1);
    endfunction
  endclass

  // Register: GEN_INTERVAL
  class reg_gen_interval extends pkt_reg_base;
    `uvm_object_utils(reg_gen_interval)
    uvm_reg_field val;
    function new(string name = "reg_gen_interval"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000002, 1, 0, 1);
    endfunction
  endclass

  // Register: GEN_COUNT
  class reg_gen_count extends pkt_reg_base;
    `uvm_object_utils(reg_gen_count)
    uvm_reg_field val;
    function new(string name = "reg_gen_count"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000004, 1, 0, 1);
    endfunction
  endclass

  // Register: IRQ_STATUS
  class reg_irq_status extends pkt_reg_base;
    `uvm_object_utils(reg_irq_status)
    uvm_reg_field val;
    function new(string name = "reg_irq_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "W1C", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: IRQ_ENABLE
  class reg_irq_enable extends pkt_reg_base;
    `uvm_object_utils(reg_irq_enable)
    uvm_reg_field val;
    function new(string name = "reg_irq_enable"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: IRQ_FORCE
  class reg_irq_force extends pkt_reg_base;
    `uvm_object_utils(reg_irq_force)
    uvm_reg_field val;
    function new(string name = "reg_irq_force"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "WO", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: ERR_STATUS
  class reg_err_status extends pkt_reg_base;
    `uvm_object_utils(reg_err_status)
    uvm_reg_field val;
    function new(string name = "reg_err_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "W1C", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: ERR_ENABLE
  class reg_err_enable extends pkt_reg_base;
    `uvm_object_utils(reg_err_enable)
    uvm_reg_field val;
    function new(string name = "reg_err_enable"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: ERR_INJECT
  class reg_err_inject extends pkt_reg_base;
    `uvm_object_utils(reg_err_inject)
    uvm_reg_field val;
    function new(string name = "reg_err_inject"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "WO", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: ERR_COUNT
  class reg_err_count extends pkt_reg_base;
    `uvm_object_utils(reg_err_count)
    uvm_reg_field val;
    function new(string name = "reg_err_count"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: ERR_INFO
  class reg_err_info extends pkt_reg_base;
    `uvm_object_utils(reg_err_info)
    uvm_reg_field val;
    function new(string name = "reg_err_info"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RO", 1, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register: LOCK
  class reg_lock extends pkt_reg_base;
    `uvm_object_utils(reg_lock)
    uvm_reg_field val;
    function new(string name = "reg_lock"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "RW", 0, 32'h00000001, 1, 0, 1);
    endfunction
  endclass

  // Register: SOFT_RESET
  class reg_soft_reset extends pkt_reg_base;
    `uvm_object_utils(reg_soft_reset)
    uvm_reg_field val;
    function new(string name = "reg_soft_reset"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      val = uvm_reg_field::type_id::create("val");
      val.configure(this, 32, 0, "WO", 0, 32'h00000000, 1, 0, 1);
    endfunction
  endclass

  // Register Block Definition
  class pkt_reg_block extends uvm_reg_block;
    `uvm_object_utils(pkt_reg_block)

    rand reg_device_id     device_id;
    rand reg_version       version;
    rand reg_switch_status switch_status;
    rand reg_port_status   port_status;
    rand reg_gen_status    gen_status;
    rand reg_stat_rx       stat_rx;
    rand reg_stat_tx       stat_tx;
    rand reg_stat_drop     stat_drop;
    rand reg_switch_ctrl   switch_ctrl;
    rand reg_port_enable   port_enable;
    rand reg_fwd_enable    fwd_enable;
    rand reg_gen_ctrl      gen_ctrl;
    rand reg_gen_pkt_cfg   gen_pkt_cfg;
    rand reg_gen_interval  gen_interval;
    rand reg_gen_count     gen_count;
    rand reg_irq_status    irq_status;
    rand reg_irq_enable    irq_enable;
    rand reg_irq_force     irq_force;
    rand reg_err_status    err_status;
    rand reg_err_enable    err_enable;
    rand reg_err_inject    err_inject;
    rand reg_err_count     err_count;
    rand reg_err_info      err_info;
    rand reg_lock          lock_reg;
    rand reg_soft_reset    soft_reset;

    uvm_reg_map apb_map;

    function new(string name = "pkt_reg_block");
      super.new(name, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      add_hdl_path("tb_top.dut");

      apb_map = create_map("apb_map", 'h0, 4, UVM_LITTLE_ENDIAN);

      device_id     = reg_device_id::type_id::create("device_id");     device_id.configure(this);     device_id.build();     apb_map.add_reg(device_id, 'h00, "RO");     device_id.add_hdl_path_slice("DEVICE_ID", 0, 32);
      version       = reg_version::type_id::create("version");         version.configure(this);       version.build();       apb_map.add_reg(version, 'h04, "RO");       version.add_hdl_path_slice("VERSION", 0, 32);
      switch_status = reg_switch_status::type_id::create("switch_status"); switch_status.configure(this); switch_status.build(); apb_map.add_reg(switch_status, 'h08, "RO"); switch_status.add_hdl_path_slice("switch_status_r", 0, 32);
      port_status   = reg_port_status::type_id::create("port_status");   port_status.configure(this);   port_status.build();   apb_map.add_reg(port_status, 'h0C, "RO");   port_status.add_hdl_path_slice("port_status_r", 0, 32);
      gen_status    = reg_gen_status::type_id::create("gen_status");    gen_status.configure(this);    gen_status.build();    apb_map.add_reg(gen_status, 'h10, "RO");    gen_status.add_hdl_path_slice("gen_status_r", 0, 32);
      stat_rx       = reg_stat_rx::type_id::create("stat_rx");         stat_rx.configure(this);       stat_rx.build();       apb_map.add_reg(stat_rx, 'h14, "RO");       stat_rx.add_hdl_path_slice("stat_rx", 0, 32);
      stat_tx       = reg_stat_tx::type_id::create("stat_tx");         stat_tx.configure(this);       stat_tx.build();       apb_map.add_reg(stat_tx, 'h18, "RO");       stat_tx.add_hdl_path_slice("stat_tx", 0, 32);
      stat_drop     = reg_stat_drop::type_id::create("stat_drop");     stat_drop.configure(this);     stat_drop.build();     apb_map.add_reg(stat_drop, 'h1C, "RO");     stat_drop.add_hdl_path_slice("stat_drop", 0, 32);
      switch_ctrl   = reg_switch_ctrl::type_id::create("switch_ctrl"); switch_ctrl.configure(this);   switch_ctrl.build();   apb_map.add_reg(switch_ctrl, 'h20, "RW");   switch_ctrl.add_hdl_path_slice("switch_ctrl_q", 0, 32);
      port_enable   = reg_port_enable::type_id::create("port_enable"); port_enable.configure(this);   port_enable.build();   apb_map.add_reg(port_enable, 'h24, "RW");   port_enable.add_hdl_path_slice("port_enable_q", 0, 4);
      fwd_enable    = reg_fwd_enable::type_id::create("fwd_enable");   fwd_enable.configure(this);    fwd_enable.build();    apb_map.add_reg(fwd_enable, 'h28, "RW");    fwd_enable.add_hdl_path_slice("fwd_enable_q", 0, 4);
      gen_ctrl      = reg_gen_ctrl::type_id::create("gen_ctrl");       gen_ctrl.configure(this);      gen_ctrl.build();      apb_map.add_reg(gen_ctrl, 'h2C, "RW");      gen_ctrl.add_hdl_path_slice("gen_ctrl_q", 0, 32);
      gen_pkt_cfg   = reg_gen_pkt_cfg::type_id::create("gen_pkt_cfg"); gen_pkt_cfg.configure(this);   gen_pkt_cfg.build();   apb_map.add_reg(gen_pkt_cfg, 'h30, "RW");   gen_pkt_cfg.add_hdl_path_slice("gen_pkt_cfg_q", 0, 32);
      gen_interval  = reg_gen_interval::type_id::create("gen_interval"); gen_interval.configure(this); gen_interval.build();  apb_map.add_reg(gen_interval, 'h34, "RW");  gen_interval.add_hdl_path_slice("gen_interval_q", 0, 16);
      gen_count     = reg_gen_count::type_id::create("gen_count");     gen_count.configure(this);     gen_count.build();     apb_map.add_reg(gen_count, 'h38, "RW");     gen_count.add_hdl_path_slice("gen_count_q", 0, 16);
      irq_status    = reg_irq_status::type_id::create("irq_status");   irq_status.configure(this);    irq_status.build();    apb_map.add_reg(irq_status, 'h3C, "RW");    irq_status.add_hdl_path_slice("irq_status_q", 0, 8);
      irq_enable    = reg_irq_enable::type_id::create("irq_enable");   irq_enable.configure(this);    irq_enable.build();    apb_map.add_reg(irq_enable, 'h40, "RW");    irq_enable.add_hdl_path_slice("irq_enable_q", 0, 8);
      irq_force     = reg_irq_force::type_id::create("irq_force");     irq_force.configure(this);     irq_force.build();     apb_map.add_reg(irq_force, 'h44, "WO");     irq_force.add_hdl_path_slice("irq_force_w", 0, 8);
      err_status    = reg_err_status::type_id::create("err_status");   err_status.configure(this);    err_status.build();    apb_map.add_reg(err_status, 'h48, "RW");    err_status.add_hdl_path_slice("err_status_q", 0, 8);
      err_enable    = reg_err_enable::type_id::create("err_enable");   err_enable.configure(this);    err_enable.build();    apb_map.add_reg(err_enable, 'h4C, "RW");    err_enable.add_hdl_path_slice("err_enable_q", 0, 8);
      err_inject    = reg_err_inject::type_id::create("err_inject");   err_inject.configure(this);    err_inject.build();    apb_map.add_reg(err_inject, 'h50, "WO");    err_inject.add_hdl_path_slice("err_inject_w", 0, 8);
      err_count     = reg_err_count::type_id::create("err_count");     err_count.configure(this);     err_count.build();     apb_map.add_reg(err_count, 'h54, "RO");     err_count.add_hdl_path_slice("err_count_q", 0, 16);
      err_info      = reg_err_info::type_id::create("err_info");       err_info.configure(this);      err_info.build();      apb_map.add_reg(err_info, 'h58, "RO");      err_info.add_hdl_path_slice("err_info_q", 0, 32);
      lock_reg      = reg_lock::type_id::create("lock_reg");           lock_reg.configure(this);      lock_reg.build();      apb_map.add_reg(lock_reg, 'h5C, "RW");      lock_reg.add_hdl_path_slice("locked", 0, 1);
      soft_reset    = reg_soft_reset::type_id::create("soft_reset");   soft_reset.configure(this);    soft_reset.build();    apb_map.add_reg(soft_reset, 'h60, "WO");    soft_reset.add_hdl_path_slice("srst_pulse", 0, 1);

      lock_model();
    endfunction
  endclass : pkt_reg_block

endpackage : pkt_ral_pkg
