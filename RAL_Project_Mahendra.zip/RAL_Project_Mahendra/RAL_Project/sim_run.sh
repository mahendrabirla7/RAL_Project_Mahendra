

#!/bin/bash

###############################################################################
# APB PACKET SWITCH - UVM RAL TESTBENCH
# Supported Simulators: QuestaSim and VCS
#
# Usage:
#   ./run_sim.sh questa
#   ./run_sim.sh vcs
###############################################################################

SIM_TOOL=${1:-questa}

TESTS=(
    "base_test"
    "error_injection_test"
    "exhaustive_config_test"
    "random_packet_test"
    "backdoor_write_frontdoor_read_test"
    "frontdoor_write_backdoor_read_test"
    "all_registers_test"
    "builtin_reg_test"
)

###############################################################################
# VCS
###############################################################################

if [ "$SIM_TOOL" == "vcs" ]; then

    echo "Starting VCS compilation..."

    mkdir -p coverage_vcs

    vcs -full64 -sverilog -ntb_opts uvm-1.2 \
        -cm line+cond+fsm+tgl+branch+assert \
        +incdir+rtl +incdir+ral +incdir+tb +incdir+tests \
        rtl/apb_pkt_pkg.sv \
        rtl/pkt_generator.sv \
        rtl/pkt_switch.sv \
        rtl/apb_pkt_switch.sv \
        ral/pkt_ral_pkg.sv \
        tb/apb_if.sv \
        tb/pkt_env_pkg.sv \
        tests/pkt_test_pkg.sv \
        tb/tb_top.sv \
        -o simv || exit 1

    VDB_FILES=()

    for tname in "${TESTS[@]}"; do

        echo "Running VCS test: $tname"

        VDB_DIR="coverage_vcs/${tname}.vdb"

        rm -rf "$VDB_DIR"

        ./simv \
            +UVM_TESTNAME="$tname" \
            -cm line+cond+fsm+tgl+branch+assert \
            -cm_dir "$VDB_DIR" \
            -cm_name "$tname" \
            -l "coverage_vcs/${tname}.log"

        if [ -d "$VDB_DIR" ]; then
            VDB_FILES+=("$VDB_DIR")
        else
            echo "ERROR: Coverage missing for $tname"
            exit 1
        fi

    done

    echo "Merging VCS coverage..."

    urg -dir "${VDB_FILES[@]}" \
        -format both \
        -report coverage_vcs/merged_report

    echo "VCS coverage report: coverage_vcs/merged_report"


###############################################################################
# QUESTA
###############################################################################

elif [ "$SIM_TOOL" == "questa" ]; then

    echo "=========================================================="
    echo "Starting QuestaSim regression"
    echo "=========================================================="

    ###########################################################################
    # CLEANUP
    ###########################################################################

    rm -rf work
    rm -rf coverage

    mkdir -p coverage

    ###########################################################################
    # STEP 1: CREATE WORK LIBRARY
    ###########################################################################

    vlib work || exit 1

    ###########################################################################
    # STEP 2: COMPILE WITH CODE AND FUNCTIONAL COVERAGE
    ###########################################################################

    echo "Compiling RTL and testbench with coverage..."

    vlog -sv \
        +acc \
        +cover \
        +fcover \
        -timescale 1ns/1ps \
        +incdir+rtl \
        +incdir+ral \
        +incdir+tb \
        +incdir+tests \
        -l coverage/compile.log \
        rtl/apb_pkt_pkg.sv \
        rtl/pkt_generator.sv \
        rtl/pkt_switch.sv \
        rtl/apb_pkt_switch.sv \
        ral/pkt_ral_pkg.sv \
        tb/apb_if.sv \
        tb/pkt_env_pkg.sv \
        tests/pkt_test_pkg.sv \
        tb/tb_top.sv

    if [ $? -ne 0 ]; then
        echo "ERROR: Compilation failed"
        exit 1
    fi

    ###########################################################################
    # STEP 3: OPTIMIZE DESIGN
    ###########################################################################

    echo "Optimizing design..."

    vopt tb_top \
        -o opt_tb_top \
        +acc

    if [ $? -ne 0 ]; then
        echo "ERROR: Optimization failed"
        exit 1
    fi

    ###########################################################################
    # STEP 4: RUN ALL TESTS AND SAVE COVERAGE
    ###########################################################################

    for tname in "${TESTS[@]}"; do

        echo
        echo "=========================================================="
        echo "Running Questa test: $tname"
        echo "=========================================================="

        TEST_DIR="coverage/${tname}"

        mkdir -p "$TEST_DIR"

        UCDB_FILE="${TEST_DIR}/${tname}_coverage.ucdb"
        LOG_FILE="${TEST_DIR}/${tname}.log"
        WLF_FILE="${TEST_DIR}/waveform.wlf"

        rm -f "$UCDB_FILE"

        #######################################################################
        # IMPORTANT:
        # coverage save -onexit registers the save operation.
        # UCDB is written when Questa exits.
        #######################################################################

        vsim -vopt \
            opt_tb_top \
            -voptargs=+acc=npr \
            -sv_seed random \
            -assertdebug \
            -sva \
            -coverage \
            -sv_lib C:/questasim64_10.7c/uvm-1.1d/win64/uvm_dpi \
            +UVM_TESTNAME="$tname" \
            +UVM_VERBOSITY=UVM_MEDIUM \
            +UVM_OBJECTION_TRACE \
            -l "$LOG_FILE" \
            -wlf "$WLF_FILE" \
            -c \
            -do "log -r /*; add wave -r /*; coverage save -onexit -assert -directive -cvg -codeAll -testname ${tname} ${UCDB_FILE}; run -all; exit"

        if [ $? -ne 0 ]; then
            echo "ERROR: Simulation failed for $tname"
            exit 1
        fi

        #######################################################################
        # CHECK UCDB
        #######################################################################

        if [ -s "$UCDB_FILE" ]; then

            echo "SUCCESS: Coverage saved: $UCDB_FILE"

        else

            echo "ERROR: Coverage database missing for $tname"
            echo "Check simulation log: $LOG_FILE"
            exit 1

        fi

        #######################################################################
        # INDIVIDUAL HTML COVERAGE REPORT
        #######################################################################

        echo "Generating HTML coverage report for $tname..."

        vcover report -html "$UCDB_FILE" \
            -htmldir "${TEST_DIR}/html_cov_report" \
            -details

    done

    ###########################################################################
    # STEP 5: MERGE ALL TEST COVERAGE
    ###########################################################################

    echo
    echo "=========================================================="
    echo "Merging Questa coverage databases..."
    echo "=========================================================="

    UCDB_FILES=()

    for tname in "${TESTS[@]}"; do
        UCDB_FILES+=("coverage/${tname}/${tname}_coverage.ucdb")
    done

    vcover merge \
        -testassociated \
        -out coverage/merged_coverage.ucdb \
        "${UCDB_FILES[@]}"

    if [ $? -ne 0 ]; then
        echo "ERROR: Coverage merge failed"
        exit 1
    fi

    ###########################################################################
    # STEP 6: MERGED HTML COVERAGE REPORT
    ###########################################################################

    echo "Generating merged HTML coverage report..."

    vcover report -html coverage/merged_coverage.ucdb \
        -htmldir coverage/merged_html_cov_report \
        -details \
        -testhitdata \
        #-testattr

    ###########################################################################
    # STEP 7: FINAL SUMMARY
    ###########################################################################

    echo
    echo "=========================================================="
    echo "ALL QUESTA TESTS COMPLETED"
    echo "=========================================================="

    echo
    echo "Generated coverage files:"
    find coverage -name "*.ucdb" -type f

    echo
    echo "Individual HTML reports:"
    echo "coverage/<test_name>/html_cov_report/index.html"

    echo
    echo "Merged HTML report:"
    echo "coverage/merged_html_cov_report/index.html"

    echo
    echo "Open merged coverage database:"
    echo "vsim -gui -viewcov coverage/merged_coverage.ucdb"

###############################################################################
# INVALID SIMULATOR
###############################################################################

else

    echo "ERROR: Unknown simulator: $SIM_TOOL"
    echo "Supported simulators: questa, vcs"
    exit 1

fi
